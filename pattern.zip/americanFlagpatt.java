public class americanFlagpatt {
    public static void main(String[] args) {
        int n=11;
        for(int i=1; i<11; i++){
            for(int j=1; j<=11; j++){
                int sum=i+j;
                if(sum %2 == 0  ){
                    System.out.print("*");
                }else{
                    System.out.print(" ");
                }
                }
                System.out.println();
            }
           
            
             for(int i=1; i<=6; i++){
                for(int j=1; j<=36; j++){
                    System.out.print("= ");
                }
                System.out.println();
             }
            }
        }
    

