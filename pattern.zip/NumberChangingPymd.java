import java.util.Scanner;
public class NumberChangingPymd {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println(" number changing Pyramid triangle :");
        System.out.println("Enter number of Rows:");
        int n=s.nextInt();
        int num=1;
        for(int i=1; i<=n; i++){
            for(int j=1; j<=i; j++){
                System.out.print(num+" ");
                num++;
           }
           System.out.println();
        }
    }
}
