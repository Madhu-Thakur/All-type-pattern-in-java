import java.util.Scanner;
public class HollowHourGlassPat {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("   Hollow HourGlass Pattern:");
        System.out.println("Enter number of Rows:");
        int n=s.nextInt();
        for(int i=1; i<=n; i++){
          for(int j=1; j<=i; j++){
              System.out.print(" ");
          }
          for(int j=n; j>=i; j--){
              if(j==n || i==1 || j==i){
                  System.out.print("* ");
              }
              else{
                  System.out.print("  ");
              }
          }
          System.out.println();
      }
      for (int i = n - 1; i >= 1; i--) {
        // inner loop to print spaces.
        for (int j = 1; j < i; j++) {
            System.out.print(" ");
        }
        // inner loop to print value of j.
        for (int j = i; j <= n; j++) {
            if(j==i||j==n||i==1)
                System.out.print("* ");
            else
                System.out.print("  ");
        }
        // printing new line for each row
        System.out.println();
    }
      }
         
        }
    
 
