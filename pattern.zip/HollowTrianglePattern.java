import java.util.Scanner;
public class HollowTrianglePattern {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("   Hollow Triangle Pattern:");
        System.out.println("Enter number of Rows:");
        int n=s.nextInt();
         for(int i=1; i<=n; i++){
            for(int j=n; j>=i; j--){
                System.out.print(" ");
            }
            for(int j=1; j<=i; j++){
                if(j==1 || i==n || j==i){
                    System.out.print("* ");
                }
                else{
                    System.out.print("  ");
                }
            }
            System.out.println();
          }
          
    }
}
