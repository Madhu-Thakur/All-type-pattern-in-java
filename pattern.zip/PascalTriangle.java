import java.util.Scanner;
public class PascalTriangle {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("  Pascal's Triangle Pattern:");
        System.out.println("Enter number of Rows:");
        int n=s.nextInt();
        for(int i=0; i<n; i++){
            for(int j=n; j>i; j--){
                System.out.print(" ");
            }
            int val=1;
            for(int j=0; j<=i; j++){
                System.out.print(val+" ");
                val=val*(i-j)/(j+1);
            }
            System.out.println();
        }
    }
}
