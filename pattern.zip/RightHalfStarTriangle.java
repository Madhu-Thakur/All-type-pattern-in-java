import java.util.Scanner;
public class RightHalfStarTriangle {
    public static void main(String[] args) {
        Scanner s=new Scanner(System.in);
        System.out.println("  Right Half Star Triangle Pattern:");
        System.out.println("Enter number of Rows:");
        int n=s.nextInt();
        for(int i=1; i<=n; i++){
            for(int j=1; j<=i; j++){
                System.out.print("* ");
            }
            System.out.println();
        }
    }
}
